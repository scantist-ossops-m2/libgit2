#!/bin/sh

set -x

brew update
brew install libssh2
